package temp;

import org.apache.http.client.fluent.Request;

public class RestRequest {
	public static int getResponseCode(String url) {
		System.out.println(url);
		try {
			return Request.Get("http://yandex.ru").execute().returnResponse().getStatusLine().getStatusCode();
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}
}
