package helpers;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;

public class PostgresHelper {

	private Connection conn;
	private String host;
	private String dbName;
	private String user;
	private String pass;
	private String selectQuery;

	protected PostgresHelper() {
	}

	public PostgresHelper(String host, String dbName, String user, String pass) {
		this.host = host;
		this.dbName = dbName;
		this.user = user;
		this.pass = pass;

		this.selectQuery = "SELECT  c.name AS contractName, to_char(c.date_doc, 'dd.mm.YYYY') as contractDate "
				+ ",l.cadaster, l.address AS landAddr, l.area AS landPlosh, cus.legal AS fizUr "
				+ ",cus.name  AS custName,cus.address AS custAddr, REPLACE(cus.uid,'  ',' ' ) as pasp "
				+ ",cus.uid_note AS paspVidan, ab.year, ab.summa, to_char(ab.date_in, 'dd.mm.YYYY') as date_in, to_char(ab.date_out, 'dd.mm.YYYY') as date_out, ccus.id AS ls "
				+ ",CASE WHEN l.ownership_id=5 THEN '04611105012040000120' "
				+ " WHEN l.ownership_id=3 THEN '04611105024040000120' ELSE '' END AS kbk "
				+ ",CONCAT('Ар.пл. за ЗУ ', l.cadaster, ' по дог.№', c.name, ' от ' , to_char(c.date_doc, 'dd.mm.YYYY') "
				+ ",', ', cus.name, ' ЛС ' , ccus.id, ' за ' , ab.year , ' г. с ', to_char(ab.date_in, 'dd.mm.YYYY') , ' по ', to_char(ab.date_out, 'dd.mm.YYYY') ) AS descr "
				+ ",ab.gisgmp_idx AS uid, ab.gisgmp, lo.name AS sobstv,ab.id chargeId "
				+ " FROM contract_contract c JOIN contract_cland cl ON (cl.contract_id = c.id) JOIN land_land l ON (l.id = cl.land_id) "
				+ " JOIN land_permitted lp ON (lp.id=l.permitted_id) "
				+ " JOIN contract_ccustomer ccus ON (ccus.contract_id=c.id AND ccus.land_id = l.id ) "
				+ " JOIN customer_customers cus ON (cus.id = ccus.customer_id) "
				+ " JOIN land_ownership lo ON lo.id=l.ownership_id "
				+ " JOIN arenda_balans ab ON (ab.contract_id=c.id AND ab.land_id=l.id AND ab.customer_id=cus.id) "
				+ " WHERE   c.state IN (1)   AND c.vidprava_id = 6 and c.autosum <> 2 AND c.name NOT IN ('Назначение платежа', 'Купля-продажа','Идентификация') "
				+ " and l.state=1  and cus.state=1  AND cl.state = 1 and ccus.state=1 "
				+ " AND l.ownership_id IN (3,5) and l.state = 1 " /* (3,5) */

				+ " and ab.gisgmp = 0 and ab.gisgmp_idx is null"
				//+ " and ab.gisgmp in (9) and ab.gisgmp_idx is not null " 
				// gisgmp = 9 -вносил до 24.03.2017 (не включительно) - =9-надо аннулировать

				+ " AND cus.legal IN ('u','f') and cus.state = 1 and ab.oper = 1 "
				+ " AND ab.state = 1 and ab.year in (2017, 2018) "
				+ "and ab.id not in (1636886,1656038,1656108, 1597344,1603973,1600789,1621034,1618601,1599583,1628125,1596945,1580205,1593879,1591247,1595983, 1590201, 1654854,1642110, 1625454) "
				// + "and ab.id in (1600066)"
				+ " order by ab.date_in limit 50000"; /*
														 * ORDER BY c.id, l.id,
														 * cus.id
														 */
	}

	public boolean openConnect() throws SQLException, ClassNotFoundException {

		if (host.isEmpty() || dbName.isEmpty() || user.isEmpty() || pass.isEmpty()) {
			throw new SQLException("Database credentials missing");
		}

		Class.forName("org.postgresql.Driver");
		this.conn = DriverManager.getConnection(this.host + this.dbName, this.user, this.pass);
		return true;
	}

	public boolean isConnectionOpen() throws SQLException {
		return !this.conn.isClosed();
	}

	public void closeConnect() throws SQLException {
		this.conn.close();
	}

	/**
	 * сделать выборку из запроса и вернуть ResultSet
	 * 
	 * @param query
	 * @return
	 * @throws SQLException
	 * @throws ClassNotFoundException
	 */
	public ResultSet executeQuery(String query) throws SQLException, ClassNotFoundException {
		if (this.conn.isClosed())
			openConnect();
		ResultSet value = this.conn.createStatement().executeQuery(query);
		closeConnect();
		return value;
	}

	/**
	 * вернуть набор данных по неначисленным из ленда
	 * 
	 * @return
	 * @throws ClassNotFoundException
	 * @throws SQLException
	 */
	public ResultSet getDataChagresFromLand() throws ClassNotFoundException, SQLException {
		// query = "select ab.gisgmp,ab.gisgmp_idx, ab.year from
		// arenda_balans ab where ab.gisgmp<>0 order by ab.gisgmp_idx";

		// query = "select count(*) from (" + this.selectQuery + ") as subq";
		// query = "select * from contract_contract c where c.id=507251";

		return executeQuery(this.selectQuery);
	}

	public String getCountDataChagresFromLand() throws ClassNotFoundException, SQLException {

		// query = "select * from contract_contract c where c.id=507251";
		ResultSet rs = executeQuery("select count(*) from (" + this.selectQuery + ") as subquery");
		rs.next();

		return rs.getString(1);
	}

	public int deleteCharge(String uin) throws ClassNotFoundException, SQLException {

		return updateQuery(
				"update arenda_balans set gisgmp_idx=null,gisgmp=0 where year=2017 and oper = 1 AND state = 1 and gisgmp <> 0 and gisgmp_idx in ('"
						+ uin + "')");
	}

	/**
	 * изменить записи в базе - вернуть кол-во изм записей
	 * 
	 * @param query
	 * @return
	 * @throws SQLException
	 * @throws ClassNotFoundException
	 */
	public int updateQuery(String query) throws SQLException, ClassNotFoundException {
		if (this.conn.isClosed())
			openConnect();
		int value = this.conn.createStatement().executeUpdate(query);
		closeConnect();
		return value;
	}

	public int updateChargeFromLand(String ab_id, String gis_uin) throws ClassNotFoundException, SQLException {
		// String q = "select count(*) from arenda_balans ab where ab.year=2017
		// and ab.oper = 1 AND ab.state = 1 and ab.gisgmp = 0 and ab.gisgmp_idx
		// is null";
		String query = "update arenda_balans set gisgmp=8, gisgmp_idx = '" + gis_uin + "' where id=" + ab_id;// gisgmp
																												// =
																												// 9
																												// -вносил
																												// до
																												// 24.03.2017
																												// (не
																												// включительно)
		return updateQuery(query);
	}

	/**
	 * вывод ResultSet на экран
	 * 
	 * @param rs
	 * @throws SQLException
	 */
	public void printResultSet(ResultSet rs) throws SQLException {
		int columns = rs.getMetaData().getColumnCount();
		// System.out.println("Количество колонок = " + columns);
		for (int i = 1; i <= columns; i++)
			System.out.print(rs.getMetaData().getColumnName(i) + "\t");
		System.out.println();

		// Перебор строк с данными
		while (rs.next()) {
			for (int i = 1; i <= columns; i++) {
				System.out.print(rs.getString(i) + "\t");
			}
			System.out.println();
		}
		// rs.first();
	}

}

/*
 * this.selectQuery =
 * "SELECT  c.name AS contractName, c.date_doc as contractDate " +
 * ",l.cadaster, l.address AS landAddr, l.area AS landPlosh, cus.legal AS fizUr "
 * +
 * ",cus.name  AS custName,cus.address AS custAddr, REPLACE(cus.uid,'  ',' ' ) as pasp "
 * +
 * ",cus.uid_note AS paspVidan, ab.year, ab.summa, ab.date_in, ab.date_out ,ccus.id AS ls "
 * + ",CASE WHEN l.ownership_id=5 THEN '04611105012040000120' " +
 * " WHEN l.ownership_id=3 THEN '04611105024040000120' ELSE '' END AS kbk " +
 * ",CONCAT('Ар.пл. за ЗУ ', l.cadaster, ' по дог.№', c.name, ' от ',c.date_doc "
 * +
 * ",', ', cus.name,' ЛС ', ccus.id,' за ',ab.year,' г. с ', ab.date_in, ' по ',ab.date_out ) AS descr "
 * + ",ab.gisgmp_idx AS uid,ab.gisgmp,lo.name AS sobstv,ab.id chargeId " +
 * " FROM contract_contract c JOIN contract_cland cl ON (cl.contract_id = c.id) JOIN land_land l ON (l.id = cl.land_id) "
 * + " JOIN land_permitted lp ON (lp.id=l.permitted_id) " +
 * " JOIN contract_ccustomer ccus ON (ccus.contract_id=c.id AND ccus.land_id = l.id ) "
 * + " JOIN customer_customers cus ON (cus.id = ccus.customer_id) " +
 * " JOIN land_ownership lo ON lo.id=l.ownership_id " +
 * " JOIN arenda_balans ab ON (ab.contract_id=c.id AND ab.land_id=l.id AND ab.customer_id=cus.id) "
 * +
 * " WHERE   c.state IN (1)   AND c.vidprava_id = 6 and c.autosum <> 2 AND c.name NOT IN ('Назначение платежа', 'Купля-продажа','Идентификация') "
 * + " and l.state=1  and cus.state=1  AND cl.state = 1 and ccus.state=1 " +
 * " AND l.ownership_id IN (3,5) and l.state = 1 and ab.gisgmp = 0 and ab.gisgmp_idx is null"
 * + " AND cus.legal IN ( 'u', 'f' ) and cus.state = 1 and ab.oper = 1 " +
 * " AND ab.state = 1 and ab.year = 2017 ORDER BY c.id, l.id, cus.id limit 3";
 */
