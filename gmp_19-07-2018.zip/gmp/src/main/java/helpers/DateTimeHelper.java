package helpers;

import java.sql.Date;
import java.text.SimpleDateFormat;

public class DateTimeHelper {

	/**
	 * 
	 * @param longStr "1490043600000"
	 * @return
	 */
	public static String getDate(String longStr){
		long ms = Long.parseLong(longStr);
		String date = new SimpleDateFormat("dd/MM/yyyy hh:mm:ss a").format(new Date(ms).getTime()); //1490043600000L
		return date;
	}
}
