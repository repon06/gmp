package helpers;

import org.openqa.selenium.By;
import org.openqa.selenium.NotFoundException;
import com.codeborne.selenide.Condition;
import com.codeborne.selenide.SelenideElement;
import static com.codeborne.selenide.WebDriverRunner.*;
import static com.codeborne.selenide.Selenide.*;
import org.openqa.selenium.NoSuchElementException;
import static com.codeborne.selenide.Selenide.$;

public class PageHelper {

	/**
	 * Отправка запроса
	 */
	private By modalInvoke = By.cssSelector(".modal#invoke-dialog");//
	/**
	 * Валидация начисления
	 */
	private By modalChargeValidation = By.cssSelector(".modal#chargeValidatingModal");//
	/**
	 * Формирование запроса
	 */
	private By modalXml = By.cssSelector(".modal#xml-dialog");//

	private By modalDialog = By.cssSelector("#outdated-ws-dialog");
	private By modalBody = By.cssSelector("div#modal-body");
	private By modalButtonClose = By.cssSelector("button.close");

	private By greenModal = By.cssSelector(".ui-pnotify");

	public void closeModalDialog() throws NoSuchElementException {
		// System.out.println("ищем лоадеры " + new SimpleDateFormat("dd.MM.yyyy
		// hh:mm").format(new Date()));
		try {

			if ($(greenModal).isDisplayed()) {
				// System.out.println($(greenModal).$(By.cssSelector(".ui-pnotify-text")).text());
				// System.out.println($(greenModal).innerHtml());

				$(greenModal).click();
				//System.out.println($(greenModal).$(".icon-remove").isDisplayed());
				// $(greenModal).$(".icon-remove").waitUntil(Condition.visible,
				// 5000);
				if ($(greenModal).$(".icon-remove").isDisplayed())
					$(greenModal).$(".icon-remove").click();

				$(greenModal).waitUntil(Condition.hidden, 30000);
			}

			// if ($(modalDialog).exists()) {
			// SelenideElement elem = $(modalDialog);
			// System.out.println(elem.getAttribute("class")+"
			// "+elem.getAttribute("style") +"
			// "+elem.getAttribute("aria-hidden")+" "+elem.getAttribute(
			// "displayed")+" "+elem.is(Condition.visible)+"
			// "+elem.isDisplayed( ));
			// System.out.println(elem.getAttribute("aria-hidden"));
			// }

			if ($(modalDialog).isDisplayed()) {

				$(modalDialog).find(modalButtonClose).click();
				$(modalDialog).waitUntil(Condition.hidden, 30000);
				// System.out.println("! CLOSE !");
			}

			// System.out.println("-----------------------------");

		} catch (NotFoundException e) {
			System.out.println("Err: " + e.getMessage());
		}

	}

	/**
	 * есть ли ошибки
	 * 
	 * @return
	 */
	public boolean isError() {
		return $$("label.error").size() > 0;
	}

	/**
	 * 
	 */
	public void waitAndCloseModalDialog() {
		// $(modalInvoke).waitUntil(Condition.visible, 50000);
		// System.out.println("wail poyavlenia");
		try {
			// System.out.println($(modalInvoke));

			$(modalXml).waitUntil(Condition.hidden, 120000);
			$(modalInvoke).waitUntil(Condition.hidden, 120000);
			$(modalChargeValidation).waitUntil(Condition.hidden, 120000);

			// System.out.println($(modalInvoke));
		} catch (Exception ex) {
			System.out.println("Error wait");
		}
	}

	public String getCookie(String name) {
		System.out.println(getWebDriver().manage().getCookieNamed(name));
		return "";
	}

}

/*
 * <div class="ui-pnotify "
 * style="width: 300px; opacity: 1; display: block; right: 25px; top: 25px; cursor: auto;"
 * ><div class="alert ui-pnotify-container alert-info ui-pnotify-shadow"
 * style="min-height: 16px;"><div class="ui-pnotify-icon"><span
 * class="glyphicon glyphicon-info-sign"></span></div><div
 * class="ui-pnotify-closer" style="cursor: pointer; visibility: hidden;"><span
 * class="glyphicon glyphicon-remove icon-remove"
 * title="Close"></span></div><div class="ui-pnotify-sticker"
 * style="cursor: pointer; visibility: hidden;"><span
 * class="glyphicon glyphicon-play icon-play" title="Stick"></span></div><h4
 * class="ui-pnotify-title" style="display: none;"></h4><div
 * class="ui-pnotify-text">Соединение с агентом завершено.</div></div></div>
 */