package helpers;

import java.net.HttpCookie;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.List;
import java.util.Map;
import java.io.*;
import org.apache.commons.lang3.StringUtils;
import org.json.simple.JSONObject;
import org.openqa.selenium.remote.JsonException;

public class HttpPostHelper {

	private static final String GET_URL = "http://172.16.0.12:8080/adapter-web/pages/app";
	private static final String login_url = "http://172.16.0.12:8080/adapter-web/rest/login?username=samoshinaea&password=12345";
	private static final String get_userprofile_url = "http://172.16.0.12:8080/adapter-web/rest/userprofile";
	private static final String post_charge_url = "http://172.16.0.12:8080/adapter-web/rest/gis-gmp/save-charge";

	private static final String post_invoke_url = "http://172.16.0.12:8080/adapter-web/rest/gis-gmp/charge/invoke/xxxxxxxxxx";// валидация:
																																// POST
	private static final String get_state_charge_url_validate = "http://172.16.0.12:8080/adapter-web/rest/gis-gmp/charge/xxxxxxxxxx/validate";// получить
																																				// статус
																																				// начисления
	private static final String get_charge_url =    "http://172.16.0.12:8080/adapter-web/rest/gis-gmp/charge?search=xxxxxxxxxx";// поискначисления
	private static final String delete_charge_url = "http://172.16.0.12:8080/adapter-web/rest/gis-gmp/charge/xxxxxxxxxx?reason=incorrect_document";
	
	//поиск предварит инфы по начисл: [{"uin":"0319423491666576230264907","payer":"26454067800645301001","status":"NEW"}]
	private static final String get_pre_charge_url ="http://172.16.0.12:8080/adapter-web/rest/gis-gmp/charge?search=xxxxxxxxxx";//&onlyMyCharges=true

	// созданные начисления по 10 штук - массив
	private static final String get_array_charge_new = "http://172.16.0.12:8080/adapter-web/rest/gis-gmp/charge?start=0&max=666&status=NEW&onlyMyCharges=true";

	private static final String USER_AGENT = "Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/56.0.2924.87 Safari/537.36";
	private static final String POST_PARAMS = "";
	static final String COOKIES_HEADER = "Set-Cookie";
	private static HttpURLConnection con = null;
	private static BufferedOutputStream bos = null;

	static java.net.CookieManager msCookieManager = new java.net.CookieManager();

	public static String getDeleteChargeUrl(String uin) {
		return delete_charge_url.replace("xxxxxxxxxx", uin);
	}
	
	public static String getPreChargeInfo(String uin) {
		return get_pre_charge_url.replace("xxxxxxxxxx", uin);
	}
	
	public static String getNewChargeArray(int max) {
		return get_array_charge_new.replace("666", max+"");
	}
	
	public static String getUrlGetCharge(String uin) {
		return get_charge_url.replace("xxxxxxxxxx", uin);
	}

	public static String getUrlGetStateChargeValidate(String uin) {
		return get_state_charge_url_validate.replace("xxxxxxxxxx", uin);
	}

	public static String getUrlPostInvoke(String uin) {
		return post_invoke_url.replace("xxxxxxxxxx", uin);
	}

	public static String getUrlPostCharge() {
		return post_charge_url;
	}

	public static String getUrlPost() {
		return login_url;
	}

	public static String getUrlUserProfile() {
		return get_userprofile_url;
	}

	/**
	 * 
	 * @param url
	 * @return
	 * @throws IOException
	 */
	public static String sendGET(String url, boolean isDebug) throws IOException {

		URL obj = new URL(url);
		con = (HttpURLConnection) obj.openConnection();
		con.setRequestMethod("GET");
		con.setRequestProperty("User-Agent", USER_AGENT);

		if (msCookieManager.getCookieStore().getCookies().size() > 0) {
			con.setRequestProperty("Cookie", StringUtils.join(msCookieManager.getCookieStore().getCookies(), ";"));
		}

		int responseCode = con.getResponseCode();
		if (isDebug) {
			System.out.println(url);
			System.out.println("GET Response Code :: " + responseCode);
		}

		if (msCookieManager.getCookieStore().getCookies().size() == 0) {
			Map<String, List<String>> headerFields = con.getHeaderFields();
			List<String> cookiesHeader = headerFields.get(COOKIES_HEADER);

			if (cookiesHeader != null)
				for (String cookie : cookiesHeader)
					if (!(HttpCookie.parse(cookie).get(0).getName().equals("rememberMe")
							&& HttpCookie.parse(cookie).get(0).getValue().equals("deleteMe"))) {
						msCookieManager.getCookieStore().add(null, HttpCookie.parse(cookie).get(0));
					}
		}

		if (responseCode == HttpURLConnection.HTTP_OK) { // success
			BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
			String inputLine;
			StringBuffer response = new StringBuffer();

			while ((inputLine = in.readLine()) != null) {
				response.append(inputLine);
			}
			in.close();
			
			if (isDebug)
				System.out.println("response: " + response.toString());
			return response.toString();
		} else {
			// System.out.println("GET request not worked");
			return null;
		}

	}

	/**
	 * 
	 * @param url
	 * @return
	 * @throws IOException
	 */
	public static String sendPOST(String url, boolean isDebug) throws IOException {

		URL obj = new URL(url);
		con = (HttpURLConnection) obj.openConnection();
		con.setRequestMethod("POST");
		con.setRequestProperty("User-Agent", USER_AGENT);
		con.setDoOutput(true);

		if (msCookieManager.getCookieStore().getCookies().size() > 0) {
			// System.out.println(StringUtils.join(msCookieManager.getCookieStore().getCookies(), ";"));
			con.setRequestProperty("Cookie", StringUtils.join(msCookieManager.getCookieStore().getCookies(), ";"));
		}

		OutputStream os = con.getOutputStream();
		os.write(POST_PARAMS.getBytes());
		os.flush();
		os.close();

		int responseCode = con.getResponseCode();
		if (isDebug) {
			System.out.println(url);
			System.out.println("POST Response Code :: " + responseCode);
		}

		if (responseCode == HttpURLConnection.HTTP_OK) { // success
			BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
			String inputLine;
			StringBuffer response = new StringBuffer();

			while ((inputLine = in.readLine()) != null) {
				response.append(inputLine);
			}
			in.close();

			if (isDebug)
				System.out.println("response: " + response.toString());
			return response.toString();

		} else if (responseCode == HttpURLConnection.HTTP_NO_CONTENT) {
			return "ok";
		} else {
			// System.out.println("POST request not worked");
			return null;
		}
	}

	
	public static String sendDelete(String url, boolean isDebug) throws IOException {

		URL obj = new URL(url);
		con = (HttpURLConnection) obj.openConnection();
		con.setRequestMethod("DELETE");
		con.setRequestProperty("User-Agent", USER_AGENT);
		con.setDoOutput(true);

		if (msCookieManager.getCookieStore().getCookies().size() > 0) {
			// System.out.println(StringUtils.join(msCookieManager.getCookieStore().getCookies(), ";"));
			con.setRequestProperty("Cookie", StringUtils.join(msCookieManager.getCookieStore().getCookies(), ";"));
		}

		OutputStream os = con.getOutputStream();
		os.write(POST_PARAMS.getBytes());
		os.flush();
		os.close();

		int responseCode = con.getResponseCode();
		if (isDebug) {
			System.out.println(url);
			System.out.println("POST Response Code :: " + responseCode);
		}

		if (responseCode == HttpURLConnection.HTTP_OK) { // success
			BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
			String inputLine;
			StringBuffer response = new StringBuffer();

			while ((inputLine = in.readLine()) != null) {
				response.append(inputLine);
			}
			in.close();

			if (isDebug)
				System.out.println("response: " + response.toString());
			return response.toString();

		} else if (responseCode == HttpURLConnection.HTTP_NO_CONTENT) {
			return "ok";
		} else {
			// System.out.println("POST request not worked");
			return null;
		}
	}
	
	/**
	 * 
	 * @param url
	 * @return
	 * @throws IOException
	 */
	public static String sendPostJson(String url, JSONObject json) {

		try {
			URL obj = new URL(url);
			con = (HttpURLConnection) obj.openConnection();
			con.setDoOutput(true);
			con.setDoInput(true);

			con.setRequestMethod("POST");

			// con.setRequestProperty("Content-Type", "application/json;
			// charset=UTF-8"); //Content-Type:application/json; charset=UTF-8
			// con.setRequestProperty("Content-Length", "" +
			// Integer.toString(parammetrs.getBytes().length));
			// con.setRequestProperty("User-Agent", USER_AGENT);
			// con.setRequestProperty("Accept", "text/plain, */*; q=0.01");
			// con.setRequestProperty("Accept-Encoding", "gzip, deflate");
			// con.setRequestProperty("Accept-Language",
			// "ru-RU,ru;q=0.8,en-US;q=0.6,en;q=0.4");

			// con.setRequestProperty("Host", "172.16.0.12:8080");
			// con.setRequestProperty("Origin", "http://172.16.0.12:8080");
			// con.setRequestProperty("Referer",
			// "http://172.16.0.12:8080/adapter-web/pages/app");
			// con.setRequestProperty("X-Requested-With", "XMLHttpRequest");
			// con.setRequestProperty("Remote Address", "172.16.0.12:8080");
			// con.setRequestProperty("Connection", "keep-alive");

			if (msCookieManager.getCookieStore().getCookies().size() > 0) {
				System.out.println(StringUtils.join(msCookieManager.getCookieStore().getCookies(), "; "));
				con.setRequestProperty("Cookie", StringUtils.join(msCookieManager.getCookieStore().getCookies(), "; "));
			}

			/*
			 * OutputStream os = con.getOutputStream();
			 * os.write(POST_PARAMS.getBytes()); os.flush(); os.close();
			 */

			con.connect();

			String jsonStr = "{\"messageData.appData.requestMessage.senderIdentifier\":\"30ae26\",\"messageData.appData.requestMessage.importRequest.package.document[0].charge.supplierOrgInfo.name\":\"Комитет по управлению имуществом города Саратова\",\"messageData.appData.requestMessage.importRequest.package.document[0].charge.supplierOrgInfo.INN\":\"6450003860\",\"messageData.appData.requestMessage.importRequest.package.document[0].charge.supplierOrgInfo.KPP\":\"645501001\",\"messageData.appData.requestMessage.importRequest.package.document[0].charge.supplierOrgInfo.account.accountNumber\":\"00000000000000000000\",\"messageData.appData.requestMessage.importRequest.package.document[0].charge.supplierOrgInfo.account.bank.name\":\"000\",\"messageData.appData.requestMessage.importRequest.package.document[0].charge.supplierOrgInfo.account.bank.BIK\":\"000000000\",\"messageData.appData.requestMessage.importRequest.package.document[0].charge.billFor\":\"test\",\"messageData.appData.requestMessage.importRequest.package.document[0].charge.totalAmount\":\"1\",\"messageData.appData.requestMessage.importRequest.package.document[0].charge.KBK\":\"0\",\"messageData.appData.requestMessage.importRequest.package.document[0].charge.OKTMO\":\"0\",\"innUl\":\"0000000000\",\"kpp\":\"000000000\",\"databasePayerName\":\"еуые\",\"senderId\":\"a9b05e50-bdbf-11e6-9598-0800200c9a66\",\"originatorId\":\"a9b05e50-bdbf-11e6-9598-0800200c9a66\",\"messageData.appData.requestMessage.senderRole\":\"1\",\"messageData.appData.requestMessage.importRequest.package.document[0].charge.budgetIndex.status\":\"02\",\"messageData.appData.requestMessage.importRequest.package.document[0].charge.budgetIndex.purpose\":\"ТП\",\"payerIdType\":\"2\",\"docType\":\"25\",\"gragd\":\"643\",\"saveMessage\":\"true\"}";

			bos = new BufferedOutputStream(con.getOutputStream());
			bos.write(json.toString().getBytes());
			// bos.write(jsonStr.getBytes());

			int responseCode = con.getResponseCode();
			System.out.println("POST Response Code :: " + responseCode);

			if (responseCode == HttpURLConnection.HTTP_OK) { // success
				BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
				String inputLine;
				StringBuffer response = new StringBuffer();

				while ((inputLine = in.readLine()) != null) {
					response.append(inputLine);
				}
				in.close();

				System.out.println("response: " + response.toString());
				return response.toString();
			} else {
				// System.out.println("POST request not worked");
				return null;
			}
		}

		catch (JsonException | IOException e) {
			System.out.println("Err http: " + e.getMessage());
			return null;
		} finally {
			try {
				bos.flush();
				bos.close();
			} catch (IOException e) {
				e.printStackTrace();
			}

		}
	}

	/**
	 * отправка начисления
	 * @param requestUrl
	 * @param payload
	 * @return UIN !!!
	 */
	public static String sendPostRequestGetUin(String requestUrl, String payload) {
		try {
			URL url = new URL(requestUrl);
			HttpURLConnection connection = (HttpURLConnection) url.openConnection();

			connection.setDoInput(true);
			connection.setDoOutput(true);
			connection.setRequestMethod("POST");
			// connection.setRequestProperty("Accept", "application/json");
			connection.setRequestProperty("Content-Type", "application/json; charset=UTF-8");

			if (msCookieManager.getCookieStore().getCookies().size() > 0) {
				// System.out.println(StringUtils.join(msCookieManager.getCookieStore().getCookies(),
				// "; "));
				connection.setRequestProperty("Cookie",
						StringUtils.join(msCookieManager.getCookieStore().getCookies(), "; "));
			}

			OutputStreamWriter writer = new OutputStreamWriter(connection.getOutputStream(), "UTF-8");
			writer.write(payload);
			writer.close();

			BufferedReader br = new BufferedReader(new InputStreamReader(connection.getInputStream()));
			StringBuffer jsonString = new StringBuffer();
			String line;
			while ((line = br.readLine()) != null) {
				jsonString.append(line);
			}
			br.close();
			connection.disconnect();

			// System.out.println(jsonString);

			return jsonString.toString();

		} catch (Exception e) {
			System.out.println(e.getMessage());
			return null;
			// throw new RuntimeException(e.getMessage());
		}

	}

}

/*
 * /* List<HttpCookie> l = msCookieManager.getCookieStore().getCookies();
 * Iterator<HttpCookie> li = l.iterator(); while (li.hasNext()) {
 * System.out.println(li.next()); }
 */

// new HttpCookie("JSESSIONID", "2E9470C4AF2F9F4C4291A20E8D9D847F")
// String cook = "JSESSIONID=2E9470C4AF2F9F4C4291A20E8D9D847F;
// rememberMe=ivX7IVnKg4XII4gao95MJfDTMPH+2TnaGsyTTAGHg/AU5pbGcVVgbTY/biTAJrB6NBybnFYQsBlM57nGhuOx9EYALrZmQt/9Ib7NRfBkyYGx7N7FsmBeyS6w/xeHFWelGrUlvrvYzPmvFXnHahyBEOBdhe/FWoYIrx8K9nZvwue1F/Geg5o9l57jffDzg33veGChUuprP1fnKmUvahAWC1T/gB30p7LadJVw6+LkC4ADGHG9I6U+I+/AO02JDmnww81vaO12z9Pueah3SXNBqhMAQMKxp8v3UA8RiS5bO808UmqIh6/tEkApB2tntOOAcKSjrHC2zhF9gksoaVBzPrw9dGSRamlcoSBPSg1jvxS2bJRpLfbApByIUgfXqGqOR1umbZVZ9y/hrebJd80zWKqJb7CMwPgJKWt4NsUs8l1PVnv2TEvped3RqY/PV/zZm8FxNjQaadYhi0+lzA3RACR+UiGhRRIBFD8+hE3WlvQfIqEOLmfCS7jp/9m+RjfPLzyV4dvcIyt2ssiKghsbsw==";
// con.setRequestProperty("Cookie", cook);

/*
 * List<HttpCookie> l = msCookieManager.getCookieStore().getCookies();
 * Iterator<HttpCookie> li = l.iterator(); while (li.hasNext()) {
 * System.out.println(li.next()); }
 */

/*
 * System.out.println(cookie);
 * System.out.println(HttpCookie.parse(cookie).get(0));
 * System.out.println(HttpCookie.parse(cookie).get(0). getName());
 * System.out.println(HttpCookie.parse(cookie).get(0). getValue());
 * System.out.println(HttpCookie.parse(cookie).get(0). getComment());
 * System.out.println(HttpCookie.parse(cookie).get(0). getPath());
 */