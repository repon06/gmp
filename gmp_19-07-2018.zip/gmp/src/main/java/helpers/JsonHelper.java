package helpers;

import org.apache.log4j.Logger;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.JSONValue;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import gis.gmp.App;
import units.Charges;
import units.InnKpp;
import utils.RegexParce;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;

import javax.naming.NameNotFoundException;

public class JsonHelper {
	private final static Logger LOG = Logger.getLogger(JsonHelper.class);

	/**
	 * 
	 * @param json
	 * @param fieldName
	 * @return
	 */
	public static String getStringFromJson(String json, String fieldName) {
		// конвертируем строку с Json в JSONObject для дальнейшего его парсинга
		String out = null;
		try {

			JSONParser parser = new JSONParser();
			Object obj = parser.parse(json);
			JSONObject jsonObj = (JSONObject) obj;
			out = jsonObj.get(fieldName).toString();
			// System.out.println(fieldName+": "+out);

		} catch (ParseException e) {
			e.printStackTrace();
		}
		return out;
	}

	public static String getStringFromJsonArray(String json, String fieldName,int row) {
		// конвертируем строку с Json в JSONObject для дальнейшего его парсинга
		String out = null;
		try {

			JSONParser parser = new JSONParser();
			Object obj = parser.parse(json);

			JSONArray entries = (JSONArray) obj;
			if (entries.size() > 0) {
				JSONObject jsonObj = (JSONObject) entries.get(row);
				out = jsonObj.get(fieldName).toString();
				// System.out.println(fieldName+": "+out);
			}
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return out;
	}

	/**
	 * генерация валидного JSON из Charges начисления
	 * 
	 * @param ch
	 * @return
	 */
	public static String generateJson(Charges ch, String senderId) {
		JSONObject outJson = null;

		try {

			String pasp = null;// пасп физ
			InnKpp ik = null;// инн-кпп юр
			String ab_id = ch.getChargeId();
			String sex = ch.getFizUr();
			String docType = null;// тип док-та

			// проверяем наличие документа
			String doc = ch.getPasp();
			if (doc.isEmpty() || doc.equals("")) {
				LOG.info("arenda_balance.id=" + ab_id + ";\tincorrect - empty documents;\t" + ch.getCustName());
				return null;// continue;
			}

			// парсим документы - т.к. у физика (пасп) может стоять
			// признак ЮР лица

			if (sex.equals("u")) {
				ik = RegexParce.getInnKpp(doc);
				if (ik == null || ik.getInn() == null || ik.getKpp() == null) {
					// если юр, но инн нет - ищем пасп - делаем физ
					ch.setFizUr("f");
					sex = "f";
				} else {
					//System.out.println("ab.id=" + ab_id + " ЮР" + " инн=" + ik.getInn() + " кпп=" + ik.getKpp() + ";\tдок=" + doc + ";\t" + ch.getCustName());
				}
			}

			if (sex.equals("f")) {
				String svid = "св.{1,9}во о рожд(\\.|ении)".toUpperCase();

				if ((doc.toUpperCase().contains(svid) || doc.toUpperCase().contains("-РУ №"))
						&& !doc.toUpperCase().contains("ПАСП")) {
					docType = "02";
					pasp = doc.toUpperCase().replaceAll(svid, "").replaceAll("от \\d{1,2}\\.\\d{2}\\.\\d{2,4}", "")
							.replaceAll("\\s+", "").replaceAll("-", "").replaceAll("№", "").replaceAll(";", "").trim();

				} else if (doc.toUpperCase().contains("СНИЛС")) {
					docType = "14";// 14=СНИЛС
					pasp = doc.toUpperCase().replaceAll("СНИЛС", "").replaceAll("[^0-9]", "").trim();
				} else {
					docType = "01";
					pasp = RegexParce.getPasp(doc);
					if (pasp == null || pasp.isEmpty() || pasp.equals("")) {
						LOG.info("arenda_balance.id=" + ab_id + ";\tincorrect documents: " + doc + ";\t"
								+ ch.getCustName());
						return null;// continue;
					} else {
						//System.out.println("ab.id=" + ab_id + " ФИЗ" + " пасп=" + pasp + " док=" + doc + " " + ch.getCustName());
					}
				}
			}

			String descr = /* "TEST " + */ ch.getDescr();

			if (descr.length() >= 154) {
				LOG.info("arenda_balance.id=" + ab_id + ";\tdescription is long: " + descr);
				return null;// continue;
			}

			outJson = new JSONObject();

			outJson.put(
					"messageData.appData.requestMessage.importRequest.package.document[0].charge.supplierOrgInfo.name",
					"Комитет по управлению имуществом города Саратова");
			outJson.put(
					"messageData.appData.requestMessage.importRequest.package.document[0].charge.supplierOrgInfo.INN",
					"6450003860");
			outJson.put(
					"messageData.appData.requestMessage.importRequest.package.document[0].charge.supplierOrgInfo.KPP",
					"645501001");
			outJson.put("originatorId", senderId);// senderId="a9b05e50-bdbf-11e6-9598-0800200c9a66"
			outJson.put("senderId", senderId);
			outJson.put("messageData.appData.requestMessage.senderRole", "1");
			outJson.put("messageData.appData.requestMessage.senderIdentifier", "30ae26");
			outJson.put("saveMessage", "true");

			// gisCharge.setNumberOfBankAccount("40101810300000010010");
			outJson.put(
					"messageData.appData.requestMessage.importRequest.package.document[0].charge.supplierOrgInfo.account.accountNumber",
					"40101810300000010010");

			// gisCharge.setBankName("Отделение Саратов г. Саратов");
			outJson.put(
					"messageData.appData.requestMessage.importRequest.package.document[0].charge.supplierOrgInfo.account.bank.name",
					"Отделение Саратов г. Саратов");

			// gisCharge.setBankBik("046311001");
			outJson.put(
					"messageData.appData.requestMessage.importRequest.package.document[0].charge.supplierOrgInfo.account.bank.BIK",
					"046311001");

			// gisCharge.setChargeOktmo("63701000");
			outJson.put("messageData.appData.requestMessage.importRequest.package.document[0].charge.OKTMO",
					"63701000");

			// gisCharge.selectStatusPayer("Налоговый агент");
			outJson.put(
					"messageData.appData.requestMessage.importRequest.package.document[0].charge.budgetIndex.status",
					"02");// 02=налоговый агент

			// gisCharge.selectPurposePayerSelect("Платежи текущего года");
			outJson.put(
					"messageData.appData.requestMessage.importRequest.package.document[0].charge.budgetIndex.purpose",
					"0");// ТП=платежи текущего года, "0" - для начислений и платежей не в пользу ФНС

			// gisCharge.setChargeDescription(descr);
			outJson.put("messageData.appData.requestMessage.importRequest.package.document[0].charge.billFor", descr);

			// gisCharge.setChargeSumm(ch.getSumma());
			outJson.put("messageData.appData.requestMessage.importRequest.package.document[0].charge.totalAmount",
					ch.getSumma());

			// gisCharge.setChargeKbk(ch.getKbk());
			outJson.put("messageData.appData.requestMessage.importRequest.package.document[0].charge.KBK", ch.getKbk());

			// gisCharge.setNalogPeriod("0");
			// gisCharge.setChargeDocNumber("0");
			// gisCharge.setChargeDocDate(ch.getDate_in());
			outJson.put(
					"messageData.appData.requestMessage.importRequest.package.document[0].charge.budgetIndex.taxPeriod",
					"0");
			outJson.put(
					"messageData.appData.requestMessage.importRequest.package.document[0].charge.budgetIndex.taxDocNumber",
					"0");
			
			outJson.put(
					"messageData.appData.requestMessage.importRequest.package.document[0].charge.budgetIndex.paymentType",
					"0"); //добавили 19-07-2018
			outJson.put(
					"endpointId",
					"fk-3998-import"); //добавили 19-07-2018
			outJson.put(
					"additionalData.enabled",
					"false"); //добавили 19-07-2018
			
			outJson.put(
					"messageData.appData.requestMessage.importRequest.package.document[0].charge.budgetIndex.taxDocDate",
					"0"
					); // 19,07,2018 - Хз почему - вместо даты надо указать 0 ??? ch.getDate_in()

			// gisCharge.setPayerName(ch.getCustName());
			outJson.put("databasePayerName", ch.getCustName());

			if (sex.equals("f")) {
				// gisCharge.selectPayerType("ФЛ");//5=ФЛ
				outJson.put("payerIdType", "5");// 5=ФЛ 2=ЮЛ— резидент РФ

				// gisCharge.selectPayerFizGragdSelect("РОССИЯ");//643=Россия
				outJson.put("gragd", "643");// 643=Россия .. гражданство

				// gisCharge.selectPayerFizDocType("паспорт гражданина
				// Российской Федерации");//01=паспорт гражданина Российской
				// Федерации
				outJson.put("docType", docType);// 01=паспорт гражданина
												// Российской Федерации; 02-свид
												// о рожд

				// gisCharge.setPayerFizdocName(pasp);
				outJson.put("numDoc", pasp);

			} else if (sex.equals("u")) {
				// gisCharge.selectPayerType("ЮЛ— резидент РФ");//2=ЮЛ— резидент
				// РФ
				outJson.put("payerIdType", "2");// 5=ФЛ 2=ЮЛ— резидент РФ
				outJson.put("docType", "25");// 01=паспорт гражданина Российской
												// Федерации 25=
				outJson.put("gragd", "643");// 643=Россия

				if (ik == null || ik.getInn() == null || ik.getInn().isEmpty() || ik.getInn().equals("")
						|| ik.getKpp() == null || ik.getKpp().isEmpty() || ik.getKpp().equals("")) {
					LOG.info("бля - недостижимо!");
					return null;// continue;
				}

				// gisCharge.setPayerUrInn(ik.getInn());
				// gisCharge.setPayerUrKpp(ik.getKpp());
				outJson.put("innUl", ik.getInn());
				outJson.put("kpp", ik.getKpp());
			}

			return outJson.toString();
		} catch (Exception e) {
			LOG.info(e.getMessage());
			return null;
		}
	}
}
