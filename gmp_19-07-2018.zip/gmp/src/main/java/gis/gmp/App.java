package gis.gmp;

import java.io.IOException;
import java.sql.Date;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.util.List;
import java.util.NoSuchElementException;

import org.apache.log4j.Logger;
import org.json.simple.JSONObject;
import org.openqa.selenium.WebDriverException;

import com.google.common.base.Strings;

import gis.gmp.pages.*;
import helpers.*;
import units.Charges;
import units.InnKpp;
import units.PostHelper;
import utils.ChargesSetter;
import utils.Config;
import utils.RegexParce;
import static com.codeborne.selenide.Selenide.*;

public class App {
	private final static Logger LOG = Logger.getLogger(App.class);

	public static void main(String[] args) {

		try {

			// подключились ли по http post ?
			String successful = null;

			// post || web
			String importType = Config.getInstance().getImportType();

			// page
			GisgmpPage gisCharge = null;

			// senderId
			String senderId = null;

			PostgresHelper client = new PostgresHelper(Config.getInstance().getBdHost(),
					Config.getInstance().getBdName(), Config.getInstance().getBdUser(),
					Config.getInstance().getBdPass());

			boolean connectionState = client.openConnect();
			System.out.println("DB connected - " + connectionState);

			// client.printResultSet(client.executeQuery(
			// "select to_char(ab.date_in, 'dd.mm.YYYY') as date_in,
			// to_char(ab.date_out, 'dd.mm.YYYY') as date_out from arenda_balans
			// ab where ab.year=2017 order by ab.date_in, ab.date_out limit
			// 10"));

			int countDataChagresFromLand = Integer.parseInt(client.getCountDataChagresFromLand());
			System.out.println("найдено невнесенных начислений: " + countDataChagresFromLand);

			ResultSet rs = client.getDataChagresFromLand();
			List<Charges> ch = ChargesSetter.getCharges(rs);

			// client.printResultSet(client.executeQuery("select distinct
			// ab.date_in, ab.date_out from arenda_balans ab where ab.year=2017
			// order by ab.date_in, ab.date_out"));

			// client.printResultSet(client.executeQuery("select count(*) from
			// arenda_balans ab where ab.year=2017 and ab.oper = 1 AND ab.state
			// = 1 and ab.gisgmp <> 0 and ab.gisgmp_idx is not null"));
			// client.printResultSet(client.executeQuery("select ab.id,
			// ab.gisgmp, ab.gisgmp_idx from arenda_balans ab where ab.year=2017
			// and ab.oper = 1 AND ab.state = 1 and ab.gisgmp <> 0 and
			// ab.gisgmp_idx is not null"));

		//	 client.updateQuery("insert into arenda_balans (oper,state,contract_id,land_id,customer_id,year,date_pay,summa,pay_doc,note,area,days) values "
		//	 		+ "(2,1,504870,500031,3571,'2014','2014.03.10',56695.74,'205','ЛС 506820 Арендная плата по договору',0,0)" );
			
			// client.updateQuery("update arenda_balans set
			// gisgmp_idx=null,gisgmp=0 where year=2017 and oper = 1 AND state =
			// 1 and gisgmp <> 0 "
			// + "and gisgmp_idx in ('0319423490155161467323329')");//"and
			// gisgmp_idx is not null and id not in (1588846,1607457)");

			// "select count(*) from arenda_balans ab where ab.year=2017 and
			// ab.oper = 1 AND ab.state = 1 and ab.gisgmp = 0 and ab.gisgmp_idx
			// is null"));
			// if
			// (RestRequest.getResponseCode(Config.getInstance().getAppLoginPageUrl())==200)

			if (importType.equals("web")) {
				System.setProperty("webdriver.chrome.driver", Config.getInstance().getChromedriverPath());
				System.setProperty("selenide.browser", "Chrome");
				open(Config.getInstance().getAppLoginPageUrl());
				gisCharge = page(LoginPage.class).login(Config.getInstance().getUserLogin(),
						Config.getInstance().getUserPassword());
			} else if (importType.equals("post")) {
				////////////////////////////////////////////////////////
				// авторизуемся на сайте POST запросами
				String postAutorisationResponse = HttpPostHelper.sendGET(HttpPostHelper.getUrlPost(), false);
				if (postAutorisationResponse != null) {
					successful = JsonHelper.getStringFromJson(postAutorisationResponse, "successful");
					System.out.println();

					String getResponse = HttpPostHelper.sendGET(HttpPostHelper.getUrlUserProfile(), false);
					if (getResponse != null) {
						// String id = JsonHelper.getStringFromJson(getResponse,
						// "id");
						senderId = JsonHelper.getStringFromJson(getResponse, "mnemonic");

						System.out.println(DateTimeHelper.getDate("1490043600000"));
						System.out.println(DateTimeHelper.getDate("1490302799999"));

					}

					// if (successful.equals("true"))
					// validatingCharge("0319423444815279282439286");
				}
			}

			// gisCharge.getCookie("JSESSIONID");
			// gisCharge.getCookie("rememberMe");

			for (int i = 0; i < ch.size(); i++) {
				String uin = null;
				uin = ch.get(i).getUid();
				String ab_id = ch.get(i).getChargeId();

				if (uin == null) {
					System.out.println(i + 1 + " из " + ch.size() + ";  ");

					if (importType.equals("web") && gisCharge != null) {
						uin = sendChargeFromGis(gisCharge, ch.get(i));
					} // web
					else if (importType.equals("post") && successful.equals("true") && senderId != null) {
						String json = JsonHelper.generateJson(ch.get(i), senderId);
						if (json != null) {
							// System.out.println(json);
							uin = HttpPostHelper.sendPostRequestGetUin(HttpPostHelper.getUrlPostCharge(),
									json.toString());
							validatingCharge(uin);
						}
					} // post

					if (uin != null) {
						client.updateChargeFromLand(ab_id, uin);
						System.out.println("arenda_balance.id=" + ab_id + "; uin=" + uin);
						LOG.info("arenda_balance.id=" + ab_id + ";\tuin=" + uin);
					}
				} // uin=0
				else {
					// ПРОВЕРЯЕМ сопоставление гис к ленду
					String payer_ = "";
					//System.out.println("arenda_balance.id=" + ab_id + "; uin=" + uin);

					String json = JsonHelper.generateJson(ch.get(i), senderId);
					if (json != null) {
						String payerIdType = JsonHelper.getStringFromJson(json, "payerIdType");
						String docType = JsonHelper.getStringFromJson(json, "docType");
						// System.out.println("payerIdType=" +
						// payerIdType);//5=ФЛ;2=ЮЛ—резиденРФ

						if (payerIdType.equals("5")) {// 5=ФЛ
							String numDoc = JsonHelper.getStringFromJson(json, "numDoc");
							String gragd = JsonHelper.getStringFromJson(json, "gragd");
							String start = docType;
							String end = numDoc.replaceAll(" ", "") + gragd;
							payer_ = Strings.padEnd(start, 25 - end.length(), '0') + end;

						} else if (payerIdType.equals("2")) {// 2=ЮЛ
							String innUl_ = JsonHelper.getStringFromJson(json, "innUl");
							String kpp_ = JsonHelper.getStringFromJson(json, "kpp");
							payer_ = "2" + innUl_ + kpp_;
						}

						// System.out.println("payer_="+payer_);

						String responseJson = HttpPostHelper.sendGET(HttpPostHelper.getPreChargeInfo(uin), false);
						String payer = JsonHelper.getStringFromJsonArray(responseJson, "payer", 0);
						// System.out.println("payer =" + payer);

						System.out.println(i + " " + payer_.equals(payer));
						// System.out.println(payer_.substring(0, 10));

						// if (!payer_.equals(payer)) { кпп не смотрим
						if (!payer_.substring(0, 11).equals(payer.substring(0, 11))) {
							LOG.info(i + " FALSE!!! arenda_balance.id=" + ab_id + ";\tuin=" + uin);
							String resultDel = HttpPostHelper.sendDelete(HttpPostHelper.getDeleteChargeUrl(uin), false);
							if (resultDel != null && resultDel.equals("ok")) {
								int resultDelSql = client.deleteCharge(uin);
								System.out.println(resultDel + resultDelSql);
							}
						}

					} else
						System.out.println("payerIdType=невалидный");// 5=ФЛ;2=ЮЛ—резиденРФ

				}
			} // for

		} catch (Exception e) {
			System.out.println("Err-1: " + e.getMessage());
			close();
		}
	}

	/**
	 * отправляем начисление на валидацию
	 * 
	 * @param uin
	 * @return
	 */
	private static boolean validatingCharge(String uin) {
		try {
			// выводить ли вспомогат инфу?
			boolean isDebug = false;

			// String uin2 = "0319423411234326909340711";
			String postResponse0 = HttpPostHelper.sendGET(HttpPostHelper.getUrlGetCharge(uin), isDebug);// 200
			// JsonHelper.getStringFromJsonArray(postResponse0, "uin");
			JsonHelper.getStringFromJsonArray(postResponse0, "status", 0);

			// request code=204 - нет вывода
			String postResponse1 = HttpPostHelper.sendPOST(HttpPostHelper.getUrlPostInvoke(uin), isDebug);// 204

			String postResponse2 = HttpPostHelper.sendGET(HttpPostHelper.getUrlGetStateChargeValidate(uin), isDebug);// 200
			if (postResponse2 != null) {
				// postResponse2="{\"status\":\"VALID\",\"description\":null}";
				JsonHelper.getStringFromJson(postResponse2, "status");
			}

			String postResponse21 = HttpPostHelper.sendPOST(HttpPostHelper.getUrlGetStateChargeValidate(uin), isDebug);// 405
			if (postResponse21 != null) {
				// postResponse2="{\"status\":\"VALID\",\"description\":null}";
				JsonHelper.getStringFromJson(postResponse21, "status");
			}
			return true;
		} catch (IOException e) {
			return false;
		}

	}

	/**
	 * отправка начисления
	 * 
	 * @param gisCharge
	 * @param ch
	 * @return
	 */
	private static String sendChargeFromGis(GisgmpPage gisCharge, Charges ch) {
		try {
			String outUin = null;

			// if this page = autorization
			if (page(LoginPage.class).isLoginPage())
				gisCharge = page(LoginPage.class).login(Config.getInstance().getUserLogin(),
						Config.getInstance().getUserPassword());

			if (gisCharge.isNewChargePanelExist())
				gisCharge.cancelButtonClick();

			String pasp = "";// пасп физ
			InnKpp ik = null;// инн-кпп юр
			String ab_id = ch.getChargeId();
			String sex = ch.getFizUr();
			String docType = null;// тип док-та

			// проверяем наличие документа
			String doc = ch.getPasp();
			if (doc.isEmpty() || doc.equals("")) {
				LOG.info("arenda_balance.id=" + ab_id + "; incorrect - empty documents; customer:" + ch.getCustName());
				return null;// continue;
			}

			// парсим документы - т.к. у физика (пасп) может стоять
			// признак ЮР лица

			if (sex.equals("u")) {
				ik = RegexParce.getInnKpp(doc);
				if (ik == null || ik.getInn() == null || ik.getKpp() == null) {
					// если юр, но инн нет - ищем пасп - делаем физ
					ch.setFizUr("f");
					sex = "f";
				}
			}

			if (sex.equals("f")) {
				String svid = "св.{1,9}во о рожд(\\.|ении)".toUpperCase();
				if ((doc.toUpperCase().contains(svid) || doc.toUpperCase().contains("-РУ №"))
						&& !doc.toUpperCase().contains("ПАСП")) {
					docType = "свидетельство органов ЗАГСа, органа исполнительной  власти  или  органа местного самоуправления о  рождении гражданина";
					pasp = doc.toUpperCase().replaceAll(svid, "").replaceAll("от \\d{1,2}\\.\\d{2}\\.\\d{2,4}", "")
							.replaceAll("\\s+", "").replaceAll("-", "").replaceAll("№", "").replaceAll(";", "").trim();

				} else {
					docType = "паспорт гражданина Российской Федерации";
					pasp = RegexParce.getPasp(doc);
					if (pasp.isEmpty() || pasp.equals("")) {
						LOG.info("arenda_balance.id=" + ab_id + "; incorrect documents: " + doc);
						return null;// continue;
					}
				}
			}

			String descr = /* "TEST " + */ ch.getDescr();

			if (descr.length() >= 154) {
				LOG.info("arenda_balance.id=" + ab_id + "; description is long: " + descr);
				return null;// continue;
			}

			System.out.println(ab_id);

			gisCharge.newChargeClick();
			gisCharge.setNumberOfBankAccount("40101810300000010010");
			gisCharge.setBankName("Отделение Саратов г. Саратов");
			gisCharge.setBankBik("046311001");
			gisCharge.setChargeOktmo("63701000");
			gisCharge.selectStatusPayer("Налоговый агент");
			gisCharge.selectPurposePayerSelect("Платежи текущего года");
			gisCharge.setChargeDescription(descr);
			gisCharge.setChargeSumm(ch.getSumma());
			gisCharge.setChargeKbk(ch.getKbk());
			gisCharge.setNalogPeriod("0");
			gisCharge.setChargeDocNumber("0");
			gisCharge.setChargeDocDate(ch.getDate_in());
			gisCharge.setPayerName(ch.getCustName());

			if (sex.equals("f")) {
				gisCharge.selectPayerType("ФЛ");
				gisCharge.selectPayerFizDocType(docType);
				gisCharge.setPayerFizdocName(pasp);
				gisCharge.selectPayerFizGragdSelect("РОССИЯ");

			} else if (sex.equals("u")) {
				gisCharge.selectPayerType("ЮЛ— резидент РФ");

				if (ik == null || ik.getInn() == null || ik.getInn().isEmpty() || ik.getInn().equals("")
						|| ik.getKpp() == null || ik.getKpp().isEmpty() || ik.getKpp().equals("")) {
					LOG.info("бля - недостижимо!");
					gisCharge.cancelButtonClick();
					return null;// continue;
				}

				gisCharge.setPayerUrInn(ik.getInn());
				gisCharge.setPayerUrKpp(ik.getKpp());
			}

			// sleep(7000);
			// gisCharge.saveButtonClick();
			if (!gisCharge.isError()) {
				gisCharge.sendButtonClick();

				String uin = gisCharge.getUinFromChagresTableGis(descr, 0);
				outUin = uin;
				System.out.println("arenda_balance.id=" + ab_id + "; uin=" + uin);

				// int updateCount = client.updateChargeFromLand(ab_id, uin);

			} else
				gisCharge.cancelButtonClick();

			return outUin;

		} catch (Throwable e) {
			System.out.println("Err0: " + e.getMessage());
			return null;
		}

	}

	/**
	 * отправить на валидацию начисления со статусом СОЗДАНО
	 * 
	 * @throws IOException
	 */
	public void sendValidationNewCharges() throws IOException {

		HttpPostHelper.sendGET(HttpPostHelper.getUrlPost(), false);
		String jsn = HttpPostHelper.sendGET(HttpPostHelper.getNewChargeArray(4), false);
		for (int i = 0; i < 4; i++) {
			String uinJsn = JsonHelper.getStringFromJsonArray(jsn, "uin", i);
			validatingCharge(uinJsn);
			System.out.println(uinJsn);
		}
	}
}
