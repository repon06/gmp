package gis.gmp.pages;

import com.codeborne.selenide.Condition;
import com.codeborne.selenide.Selectors;
import static com.codeborne.selenide.Selenide.$;
import helpers.PageHelper;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;

public class GisgmpPage extends PageHelper {

	private By gisgmp_view = By.cssSelector(".gisgmp-view");
	private By newChargeButton = By.xpath(".//button[text()='Новое начисление']");
	private By searchField = By.cssSelector("input.conversation-search");

	private By tableChargesGis = By.cssSelector("table#conversationsGrid tbody");

	// модальное оконо с начислением
	private By newGisgmpRequestPanel = By.cssSelector("#newGisgmpRequestModal");
	// Дата, вплоть до которой актуально начисление
	private By actualToDate = By.cssSelector("#validUntil");
	// Номер банковского счёта
	private By numberOfBankAccount = By.id(
			"messageData.appData.requestMessage.importRequest.package.document[0].charge.supplierOrgInfo.account.accountNumber");
	// Наименование структурного подразделения кредитной организации или
	// подразделения Банка России, в котором открыт счет
	private By bankName = By.id(
			"messageData.appData.requestMessage.importRequest.package.document[0].charge.supplierOrgInfo.account.bank.name");

	private By bankBik = By.id(
			"messageData.appData.requestMessage.importRequest.package.document[0].charge.supplierOrgInfo.account.bank.BIK");
	private By chargeDescription = By
			.id("messageData.appData.requestMessage.importRequest.package.document[0].charge.billFor");
	private By chargeSumm = By
			.id("messageData.appData.requestMessage.importRequest.package.document[0].charge.totalAmount");

	private By chargeKbk = By.id("messageData.appData.requestMessage.importRequest.package.document[0].charge.KBK");
	private By chargeOktmo = By.id("messageData.appData.requestMessage.importRequest.package.document[0].charge.OKTMO");

	/*
	 * private By statusPayer = By .id(
	 * "s2id_messageData.appData.requestMessage.importRequest.package.document[0].charge.budgetIndex.status"
	 * );
	 */

	private By statusPayerSelect = By
			.id("messageData.appData.requestMessage.importRequest.package.document[0].charge.budgetIndex.status");

	private By purposePayerSelect = By
			.id("messageData.appData.requestMessage.importRequest.package.document[0].charge.budgetIndex.purpose");

	private By nalogPeriod = By
			.id("messageData.appData.requestMessage.importRequest.package.document[0].charge.budgetIndex.taxPeriod");
	private By chargeDocNumber = By
			.id("messageData.appData.requestMessage.importRequest.package.document[0].charge.budgetIndex.taxDocNumber");
	private By chargeDocDate = By
			.id("messageData.appData.requestMessage.importRequest.package.document[0].charge.budgetIndex.taxDocDate");

	private By chargeTypeSelect = By.cssSelector(
			"select[id='messageData.appData.requestMessage.importRequest.package.document[0].charge.budgetIndex.paymentType'");

	private By payerTypeSelect = By.id("payerIdType"); // "ФЛ" "ЮЛ— резидент РФ"

	private By payerFizDocType = By.id("docType"); // "паспорт гражданина
													// Российской Федерации"
	private By payerFizdocName = By.id("numDoc"); //
	private By payerFizGragdSelect = By.id("gragd");// РОССИЯ

	private By payerUrInn = By.id("innUl");
	private By payerUrKpp = By.id("kpp");

	private By payerName = By.id("databasePayerName"); // имя плательщика

	private By saveButton = By.id("saveNewGisgmpCharge");
	private By sendButton = By.id("sendNewGisgmpCharge");
	private By cancelButton = By.xpath(".//button[text()='Отмена']");

	// выбор шаблонов ГИС
	private By loadDataFromTemplateButton = By.cssSelector("button.load-charge-template-btn");
	private By newChargeTemplatePanel = By.cssSelector("#listChargeTemplatesModal");
	private By listTemplates = By.cssSelector("ul.templates-list li.private label");
	private By templateApplyButton = By.cssSelector("button.apply-charge-template-btn");
	private By templateCancelButton = By.cssSelector("button.btn-default");

	public GisgmpPage() {
		if (isGisGmpPage()) {
			// System.out.println("goto GisgmpPage");
			closeModalDialog();
		}
	}

	public boolean isGisGmpPage() {
		return $(gisgmp_view).isDisplayed();
	}

	/**
	 * Новое начисление
	 * 
	 * @return
	 */
	public GisgmpPage newChargeClick() {
		closeModalDialog();
		// if (!$("#outdated-ws-dialog").isDisplayed())
		// System.out.println($("#outdated-ws-dialog").getAttribute("class"));
		$(newChargeButton).click();
		$(newGisgmpRequestPanel).waitUntil(Condition.visible, 10000);
		closeModalDialog();
		return this;
	}

	public boolean isNewChargePanelExist() {
		return $(newGisgmpRequestPanel).isDisplayed();
	}

	/**
	 * заполнить из шаблона
	 * 
	 * @return
	 */
	public GisgmpPage loadDataFromTemplateClick() {
		closeModalDialog();
		$(loadDataFromTemplateButton).click();
		$(newChargeTemplatePanel).waitUntil(Condition.visible, 10000);
		return this;
	}

	public boolean isNewChargeTemplatePanelExist() {
		return $(newChargeTemplatePanel).isDisplayed();
	}

	public GisgmpPage selectTemplate(String templateName) {
		if (isNewChargeTemplatePanelExist()) {
			// System.out.println($(newChargeTemplatePanel).findAll(listTemplates).size());
			$(newChargeTemplatePanel).$$(listTemplates).find(Condition.text(templateName)).click();
		}
		return this;
	}

	public GisgmpPage templateApplyButtonClick() {
		$(templateApplyButton).click();
		closeModalDialog();

		return this;
	}

	public GisgmpPage setNumberOfBankAccount(String value) {
		$(numberOfBankAccount).val(value);
		return this;
	}

	public GisgmpPage setBankName(String value) {
		$(bankName).val(value);
		return this;
	}

	public GisgmpPage setBankBik(String value) {
		$(bankBik).val(value);
		return this;
	}

	public GisgmpPage setChargeDescription(String value) {
		$(chargeDescription).val(value);
		return this;
	}

	public GisgmpPage setChargeSumm(String value) {
		$(chargeSumm).val(value);
		return this;
	}

	public GisgmpPage setChargeKbk(String value) {
		$(chargeKbk).val(value);
		return this;
	}

	public GisgmpPage setChargeOktmo(String value) {
		$(chargeOktmo).val(value);

		return this;
	}

	/**
	 * выбрать статуст плательщика
	 * 
	 * @param state
	 * @return
	 */
	public GisgmpPage selectStatusPayer(String value) {
		// $(statusPayer).click();
		$(statusPayerSelect).selectOption(value);
		// screenshot("opla.png");
		return this;
	}

	/**
	 * выбрать - Показатель основания платежа
	 * 
	 * @param value
	 * @return
	 */
	public GisgmpPage selectPurposePayerSelect(String value) {
		$(purposePayerSelect).selectOption(value);
		return this;
	}

	/**
	 * Налоговый период <br>
	 * 'МС.02.2013'; 'КВ.01.2013'; 'ПЛ.02.2013'; 'ГД.00.2013'; '04.09.2013'
	 * 
	 * @param value
	 * @return
	 */
	public GisgmpPage setNalogPeriod(String value) {
		$(nalogPeriod).val(value);
		return this;
	}

	/**
	 * номера документа начисления
	 * 
	 * @param value
	 * @return
	 */
	public GisgmpPage setChargeDocNumber(String value) {
		$(chargeDocNumber).val(value);
		return this;
	}

	public GisgmpPage setChargeDocDate(String value) {
		$(chargeDocDate).val(value);
		return this;
	}

	/**
	 * Показатель типа платежа - уплата пени, процент, другое
	 * 
	 * @param value
	 * @return
	 */
	public GisgmpPage selectChargeTypeSelect(String value) {
		$(chargeTypeSelect).selectOption(value);
		return this;
	}

	public GisgmpPage selectPayerType(String value) {
		$(payerTypeSelect).selectOption(value);
		return this;
	}

	/**
	 * документ плательщика
	 * 
	 * @param value
	 * @return
	 */
	public GisgmpPage selectPayerFizDocType(String value) {
		$(payerFizDocType).selectOption(value);
		return this;
	}

	/**
	 * номер - сер док-та плательщика
	 * 
	 * @param value
	 * @return
	 */
	public GisgmpPage setPayerFizdocName(String value) {
		$(payerFizdocName).val(value);
		return this;
	}

	/**
	 * гражданство
	 * 
	 * @param value
	 * @return
	 */
	public GisgmpPage selectPayerFizGragdSelect(String value) {
		$(payerFizGragdSelect).selectOption(value);
		return this;
	}

	public GisgmpPage setPayerName(String value) {
		$(payerName).val(value);
		// sleep(5000);
		return this;
	}

	public GisgmpPage setPayerUrInn(String value) {
		$(payerUrInn).val(value);
		// sleep(5000);
		return this;
	}

	public GisgmpPage setPayerUrKpp(String value) {
		$(payerUrKpp).val(value);
		// sleep(5000);
		return this;
	}

	public GisgmpPage cancelButtonClick() {
		closeModalDialog();
		$(newGisgmpRequestPanel).$(cancelButton).click();
		$(newGisgmpRequestPanel).waitUntil(Condition.disappear, 10000);
		closeModalDialog();
		return this;
	}

	public GisgmpPage saveButtonClick() {
		closeModalDialog();
		$(newGisgmpRequestPanel).$(saveButton).click();
		$(newGisgmpRequestPanel).waitUntil(Condition.disappear, 10000);
		closeModalDialog();
		return this;
	}

	public GisgmpPage sendButtonClick() {
		closeModalDialog();
		$(newGisgmpRequestPanel).$(sendButton).click();
		waitAndCloseModalDialog();
		// if ($(newGisgmpRequestPanel).isDisplayed())
		$(newGisgmpRequestPanel).waitUntil(Condition.disappear, 30000);
		closeModalDialog();
		return this;
	}

	/**
	 * извлекаем из вновь внесенного начисления его уин
	 * 
	 * @param descr
	 * @return
	 */
	public String getUinFromChagresTableGis(String descr, int iter) {

		try {
			$(tableChargesGis).waitUntil(Condition.text(descr), 15000);

			String uin = $(tableChargesGis).find(Selectors.byText(descr)).closest("tr")
					.find(Selectors.byCssSelector("td.uin")).text();
			return uin;
			// } catch (NoSuchElementException |
			// java.util.NoSuchElementException ex) {
		} catch (Exception z) {
			if (iter < 6)
				return getUinFromChagresTableGis(descr, iter++);
			else
				return null;
		}
	}

}
