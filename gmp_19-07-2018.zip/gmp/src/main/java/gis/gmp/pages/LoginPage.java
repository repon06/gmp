package gis.gmp.pages;

import static com.codeborne.selenide.Selenide.*;
import helpers.PageHelper;
import org.openqa.selenium.By;

import static com.codeborne.selenide.Selenide.$;
import static com.codeborne.selenide.Selenide.page;

public class LoginPage extends PageHelper {
	private By loginModal = By.cssSelector("#loginModal");
	private By login = By.cssSelector("input#tynamoLoginUsername");
	private By pass = By.cssSelector("input#tynamoPassword");
	private By submit = By.cssSelector("button#loginButton");

	public LoginPage() {
		if (isLoginPage()) {
			// System.out.println("goto LoginPage");
			closeModalDialog();
		}
	}

	public boolean isLoginPage() {
		return $(loginModal).isDisplayed();
	}

	public GisgmpPage login(String login, String password) {
		$(this.login).val(login);
		$(this.pass).val(password);
		$(this.submit).click();
		return page(GisgmpPage.class);
	}

}
