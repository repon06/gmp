package units;

import java.net.CookieHandler;
import java.net.CookieManager;
import java.net.CookiePolicy;
import java.net.HttpCookie;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;
import java.security.cert.Certificate;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.io.*;

import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLPeerUnverifiedException;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;

public class PostHelper {

	private static String USER_AGENT = "Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/56.0.2924.87 Safari/537.36";

	public static void post(String http_url) {
		try {
			URL url = new URL(http_url);
			HttpURLConnection conn = (HttpURLConnection) url.openConnection();
			conn.setReadTimeout(10000);
			conn.setConnectTimeout(15000);
			conn.setRequestMethod("POST");
			conn.setDoInput(true);
			conn.setDoOutput(true);

			List<NameValuePair> params = new ArrayList<NameValuePair>();
			params.add(new BasicNameValuePair("username", "samoshinaea"));
			params.add(new BasicNameValuePair("password", "12345"));
			params.add(new BasicNameValuePair("_", "1490090927739"));

			System.out.println(getQuery(params));

			OutputStream os = conn.getOutputStream();
			BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(os, "UTF-8"));
			writer.write(getQuery(params));
			writer.flush();
			writer.close();
			os.close();

			conn.connect();

			System.out.println("Response Code : " + conn.getResponseCode());

			System.out.println("Set-Cookie : " + conn.getHeaderField("Set-Cookie"));
			System.out.println("Cookie : " + conn.getHeaderField("Cookie"));
			System.out.println("getResponseMessage : " + conn.getResponseMessage());
			System.out.println("getResponseMessage : " + conn.getHeaderField(""));
			System.out.println("getHeaderFields : " + conn.getHeaderFields().size());

		} catch (Exception e) {
		}
	}

	private static String getQuery(List<NameValuePair> params) throws UnsupportedEncodingException {
		StringBuilder result = new StringBuilder();
		boolean first = true;

		for (NameValuePair pair : params) {
			if (first)
				first = false;
			else
				result.append("&");

			result.append(URLEncoder.encode(pair.getName(), "UTF-8"));
			result.append("=");
			result.append(URLEncoder.encode(pair.getValue(), "UTF-8"));
		}

		return result.toString();
	}

	/**
	 * "https://www.google.com/"
	 * 
	 * @param https_url
	 */
	public static void testIt(String https_url) {
		System.out.println("run testIt");

		URL url;

		try {

			url = new URL(https_url);
			if (https_url.contains("https:")) {
				HttpsURLConnection con = (HttpsURLConnection) url.openConnection();
				// dumpl all cert info
				print_https_cert(con);
				// dump all the content
				print_content(con);
			} else if (https_url.contains("http:")) {
				HttpURLConnection con = (HttpURLConnection) url.openConnection();
				System.out.println("Response Code : " + con.getResponseCode());

				System.out.println("Set-Cookie : " + con.getHeaderField("Set-Cookie"));
				System.out.println("Cookie : " + con.getHeaderField("Cookie"));
				System.out.println("Cookie : " + con.getRequestProperty("Cookie"));
				System.out.println("getHeaderFields : " + con.getHeaderFields().size());
				// dump all the content
				// print_content(con);
			}

		} catch (MalformedURLException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

	private static void print_https_cert(HttpsURLConnection con) {

		if (con != null) {
			try {
				System.out.println("Response Code : " + con.getResponseCode());
				System.out.println("Cipher Suite : " + con.getCipherSuite());
				System.out.println("\n");

				Certificate[] certs = con.getServerCertificates();
				for (Certificate cert : certs) {
					System.out.println("Cert Type : " + cert.getType());
					System.out.println("Cert Hash Code : " + cert.hashCode());
					System.out.println("Cert Public Key Algorithm : " + cert.getPublicKey().getAlgorithm());
					System.out.println("Cert Public Key Format : " + cert.getPublicKey().getFormat());
					System.out.println("\n");
				}
			} catch (SSLPeerUnverifiedException e) {
				e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}

	private static void print_content(HttpURLConnection con) {
		if (con != null) {

			try {

				System.out.println("****** Content of the URL ********");
				BufferedReader br = new BufferedReader(new InputStreamReader(con.getInputStream()));

				String input;

				while ((input = br.readLine()) != null) {
					System.out.println(input);
				}
				br.close();

			} catch (IOException e) {
				e.printStackTrace();
			}
		}

	}

	// HTTP GET request
	public static void sendGet() throws Exception {

		String url = "http://www.google.com/search?q=mkyong";

		URL obj = new URL(url);
		HttpURLConnection con = (HttpURLConnection) obj.openConnection();

		// optional default is GET
		con.setRequestMethod("GET");

		// add request header
		con.setRequestProperty("User-Agent", USER_AGENT);

		int responseCode = con.getResponseCode();
		System.out.println("\nSending 'GET' request to URL : " + url);
		System.out.println("Response Code : " + responseCode);

		BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
		String inputLine;
		StringBuffer response = new StringBuffer();

		while ((inputLine = in.readLine()) != null) {
			response.append(inputLine);
		}
		in.close();

		// print result
		System.out.println(response.toString());

	}

	/**
	 * HTTP POST request
	 * http://10.1.254.12:8080/adapter-web/rest/login?username=samoshinaea&password=12345&_=1490104600436
	 * 
	 * @throws Exception
	 */
	public static void sendPost() throws Exception {

		// CookieHandler.setDefault(new CookieManager());
		CookieHandler.setDefault(new CookieManager(null, CookiePolicy.ACCEPT_ALL));

		String url = "http://10.1.254.12:8080/adapter-web/rest/login";// "http://10.1.254.12:8080/adapter-web/rest/login?"
		URL obj = new URL(url);
		HttpURLConnection con = (HttpURLConnection) obj.openConnection();

		// add reuqest header
		con.setRequestMethod("POST");
		con.setRequestProperty("User-Agent", USER_AGENT);
		con.setRequestProperty("Accept-Language", "ru-RU,ru;q=0.8,en-US;q=0.6,en;q=0.4");

		String urlParameters = "username=samoshinaea&password=12345"; // &_=1490104600436

		// Send post request
		con.setDoOutput(true);
		DataOutputStream wr = new DataOutputStream(con.getOutputStream());
		wr.writeBytes(urlParameters);
		wr.flush();
		wr.close();

		int responseCode = con.getResponseCode();
		System.out.println("\nSending 'POST' request to URL : " + url);
		System.out.println("Post parameters : " + urlParameters);
		System.out.println("Response Code : " + responseCode);

		BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
		String inputLine;
		StringBuffer response = new StringBuffer();

		while ((inputLine = in.readLine()) != null) {
			response.append(inputLine);
		}
		in.close();

		con = (HttpURLConnection) new URL("http://10.1.254.12:8080/adapter-web/pages/app#gisgmp-charges")
				.openConnection();
		String cookie = con.getHeaderField("Set-Cookie");
		System.out.println("Cookie : " + cookie);
		System.out.println("Response Code : " + con.getResponseCode());

		// print result
		System.out.println(response.toString());
	}

	public static void sendPost2() throws Exception {
		String COOKIES_HEADER = "Set-Cookie";
		
		// CookieHandler.setDefault(new CookieManager());
		CookieHandler.setDefault(new CookieManager(null, CookiePolicy.ACCEPT_ALL));

		String url = "http://10.1.254.12:8080/adapter-web/rest/login?username=samoshinaea&password=12345&_=1490090927739";// "http://10.1.254.12:8080/adapter-web/rest/login?"
		URL obj = new URL(url);
		HttpURLConnection con = (HttpURLConnection) obj.openConnection();

		// add reuqest header
		//con.setRequestMethod("POST"); //GET, POST, PUT, DELETE, OPTIONS
		con.setRequestProperty("User-Agent", USER_AGENT);
		con.setRequestProperty("Accept-Language", "ru-RU,ru;q=0.8,en-US;q=0.6,en;q=0.4");

		
		


		// Send post request
		con.setDoOutput(true);

		int responseCode = con.getResponseCode();
		System.out.println("\nSending 'POST' request to URL : " + url);
		//System.out.println("Post parameters : " + urlParameters);
		System.out.println("Response Code : " + responseCode);

		BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
		String inputLine;
		StringBuffer response = new StringBuffer();

		while ((inputLine = in.readLine()) != null) {
			response.append(inputLine);
		}
		in.close();

		con = (HttpURLConnection) new URL("http://10.1.254.12:8080/adapter-web/pages/app#gisgmp-charges").openConnection();

		java.net.CookieManager msCookieManager = new java.net.CookieManager();

		Map<String, List<String>> headerFields = con.getHeaderFields();
		List<String> cookiesHeader = headerFields.get(COOKIES_HEADER);

		if (cookiesHeader != null) {
		    for (String cookie : cookiesHeader) {
		        msCookieManager.getCookieStore().add(null,HttpCookie.parse(cookie).get(0));
		    }               
		}

		System.out.println("Cookie : " + con.getHeaderField("Set-Cookie"));
		System.out.println("Response Code : " + con.getResponseCode());
		System.out.println("HttpCookie Code : " + con.getHeaderField("HttpCookie"));
		System.out.println("HttpCookie Code : " + con.getHeaderField("JSESSIONID"));
		System.out.println("get : " + con.getHeaderFields().get(COOKIES_HEADER));


		// print result
		System.out.println(response.toString());
	}
	
}
