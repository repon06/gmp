package units;

/**
 * класс с полями начисления из гис гмп
 * 
 * @author бдм 08.03.2017
 *
 */
public class Charges /*extends List*/ {

	private String contractName;
	private String contractDate;
	private String cadaster;
	private String landAddr;
	private String landPlosh;
	private String fizUr;
	private String custName;
	private String custAddr;
	private String pasp;
	private String paspVidan;
	private String year;
	private String summa;
	private String date_in;
	private String date_out;
	private String ls;
	private String kbk;
	private String descr;
	private String uid;
	private String gisgmp;
	private String sobstv;
	private String chargeId;

	public String getContractDate() {
		return contractDate;
	}

	public void setContractDate(String contractDate) {
		this.contractDate = contractDate;
	}

	public String getCadaster() {
		return cadaster;
	}

	public void setCadaster(String cadaster) {
		this.cadaster = cadaster;
	}

	public String getLandAddr() {
		return landAddr;
	}

	public void setLandAddr(String landAddr) {
		this.landAddr = landAddr;
	}

	public String getLandPlosh() {
		return landPlosh;
	}

	public void setLandPlosh(String landPlosh) {
		this.landPlosh = landPlosh;
	}

	public String getFizUr() {
		return fizUr;
	}

	public void setFizUr(String fizUr) {
		this.fizUr = fizUr;
	}

	public String getCustName() {
		return custName;
	}

	public void setCustName(String custName) {
		this.custName = custName;
	}

	public String getCustAddr() {
		return custAddr;
	}

	public void setCustAddr(String custAddr) {
		this.custAddr = custAddr;
	}

	public String getPasp() {
		return pasp;
	}

	public void setPasp(String pasp) {
		this.pasp = pasp;
	}

	public String getPaspVidan() {
		return paspVidan;
	}

	public void setPaspVidan(String paspVidan) {
		this.paspVidan = paspVidan;
	}

	public String getYear() {
		return year;
	}

	public void setYear(String year) {
		this.year = year;
	}

	public String getSumma() {
		return summa;
	}

	public void setSumma(String summa) {
		this.summa = summa;
	}

	public String getDate_in() {
		return date_in;
	}

	public void setDate_in(String date_in) {
		this.date_in = date_in;
	}

	public String getDate_out() {
		return date_out;
	}

	public void setDate_out(String date_out) {
		this.date_out = date_out;
	}

	public String getLs() {
		return ls;
	}

	public void setLs(String ls) {
		this.ls = ls;
	}

	public String getKbk() {
		return kbk;
	}

	public void setKbk(String kbk) {
		this.kbk = kbk;
	}

	public String getDescr() {
		//убираем лишние пробелы
		String descript = descr.replaceAll("\\s{2,}", " ").trim();
		
		if (descript.length() >= 154) 
			descript = descript.substring(0, descript.indexOf(" г. с "));//обрезаем, если оч длин
			
		setDescr(descript); 
		
		return descript;
	}

	public void setDescr(String descr) {
		this.descr = descr;
	}

	public String getUid() {
		return uid;
	}

	public void setUid(String uid) {
		this.uid = uid;
	}

	public String getGisgmp() {
		return gisgmp;
	}

	public void setGisgmp(String gisgmp) {
		this.gisgmp = gisgmp;
	}

	public String getSobstv() {
		return sobstv;
	}

	public void setSobstv(String sobstv) {
		this.sobstv = sobstv;
	}

	public String getChargeId() {
		return chargeId;
	}

	public void setChargeId(String chargeId) {
		this.chargeId = chargeId;
	}

	public String getContractName() {
		return contractName;
	}

	public void setContractName(String contractName) {
		this.contractName = contractName;
	}

}
