package units;

import java.util.regex.Pattern;

public class InnKpp {
	public InnKpp() {
		setInn(null);
		setKpp(null);
	}

	private static String inn;
	private static String kpp;

	public String getInn() {
		return inn;
	}

	public void setInn(String value) {
		inn = value;
	}

	public String getKpp() {
		return kpp;
	}

	public void setKpp(String value) {
		kpp = value;
	}

	/**
	 * проверка КПП по регулярному выражению
	 * 
	 * @param KPPstring
	 *            КПП для проверки
	 * @return >true - если проходит проверку, false - если не проходит проверку
	 */
	public static boolean check_KPP(String KPPstring) {
		if (KPPstring.length() == 9) {
			// return new
			// Regex("\\d{4}[\\dA-Z][\\dA-Z]\\d{3}").IsMatch(KPPstring);
			Pattern regex = Pattern.compile("\\d{4}[\\dA-Z][\\dA-Z]\\d{3}");

			return regex.matcher(KPPstring).find();
		} else
			return false;
	}

	/**
	 * проверка ИНН по контрольной цифре
	 * 
	 * @param INNstring
	 *            ИНН для проверки
	 * @return true - если проходит проверку, false - если не проходит проверку
	 */
	public static boolean check_INN(String INNstring) {
		// является ли вообще числом
		try {
			Long.parseLong(INNstring);
		} catch (NumberFormatException e) {
			return false;
		}

		// проверка на 10 и 12 цифр
		if (INNstring.length() != 10 && INNstring.length() != 12) {
			return false;
		}

		// проверка по контрольным цифрам
		if (INNstring.length() == 10) { // для юридического лица
			long dgt10 = (long) 0;
			try {

				dgt10 = (((2 * Long.parseLong(INNstring.substring(0, 1)) + 4 * Long.parseLong(INNstring.substring(1, 2))
						+ 10 * Long.parseLong(INNstring.substring(2, 3)) + 3 * Long.parseLong(INNstring.substring(3, 4))
						+ 5 * Long.parseLong(INNstring.substring(4, 5)) + 9 * Long.parseLong(INNstring.substring(5, 6))
						+ 4 * Long.parseLong(INNstring.substring(6, 7)) + 6 * Long.parseLong(INNstring.substring(7, 8))
						+ 8 * Long.parseLong(INNstring.substring(8, 9))) % 11) % 10);
			} catch (Exception e) {
				return false;
			}

			if (Long.parseLong(INNstring.substring(9, 10)) == dgt10) {
				return true;
			} else {
				return false;
			}
		} else { // для физического лица
			long dgt11 = 0, dgt12 = 0;
			try {
				dgt11 = (((7 * Long.parseLong(INNstring.substring(0, 1)) + 2 * Long.parseLong(INNstring.substring(1, 2))
						+ 4 * Long.parseLong(INNstring.substring(2, 3)) + 10 * Long.parseLong(INNstring.substring(3, 4))
						+ 3 * Long.parseLong(INNstring.substring(4, 5)) + 5 * Long.parseLong(INNstring.substring(5, 6))
						+ 9 * Long.parseLong(INNstring.substring(6, 7)) + 4 * Long.parseLong(INNstring.substring(7, 8))
						+ 6 * Long.parseLong(INNstring.substring(8, 9))
						+ 8 * Long.parseLong(INNstring.substring(9, 10))) % 11) % 10);
				dgt12 = (((3 * Long.parseLong(INNstring.substring(0, 1)) + 7 * Long.parseLong(INNstring.substring(1, 2))
						+ 2 * Long.parseLong(INNstring.substring(2, 3)) + 4 * Long.parseLong(INNstring.substring(3, 4))
						+ 10 * Long.parseLong(INNstring.substring(4, 5)) + 3 * Long.parseLong(INNstring.substring(5, 6))
						+ 5 * Long.parseLong(INNstring.substring(6, 7)) + 9 * Long.parseLong(INNstring.substring(7, 8))
						+ 4 * Long.parseLong(INNstring.substring(8, 9)) + 6 * Long.parseLong(INNstring.substring(9, 10))
						+ 8 * Long.parseLong(INNstring.substring(10, 11))) % 11) % 10);
			} catch (Exception e) {
				return false;
			}
			if (Long.parseLong(INNstring.substring(10, 11)) == dgt11
					&& Long.parseLong(INNstring.substring(11, 12)) == dgt12) {
				return true;
			} else {
				return false;
			}
		}
	}

}
