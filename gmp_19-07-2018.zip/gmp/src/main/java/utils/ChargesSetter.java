package utils;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import units.Charges;

public class ChargesSetter {

	public static List<Charges> getCharges(ResultSet rs) throws SQLException {

		List<Charges> listCharges = new ArrayList<Charges>();

		while (rs.next()) {
			Charges ch = new Charges();
			ch.setContractName(rs.getString("contractname"));
			ch.setContractDate(rs.getString("contractdate"));
			ch.setCadaster(rs.getString("cadaster"));
			ch.setLandAddr(rs.getString("landAddr"));
			ch.setLandPlosh(rs.getString("landPlosh"));
			ch.setFizUr(rs.getString("fizUr"));
			ch.setCustName(rs.getString("custName"));
			ch.setCustAddr(rs.getString("custAddr"));
			ch.setPasp(rs.getString("pasp"));
			ch.setPaspVidan(rs.getString("paspVidan"));
			ch.setYear(rs.getString("year"));
			ch.setSumma(rs.getString("summa"));
			ch.setDate_in(rs.getString("date_in"));
			ch.setDate_out(rs.getString("date_out"));
			ch.setLs(rs.getString("ls"));
			ch.setKbk(rs.getString("kbk"));
			ch.setDescr(rs.getString("descr"));
			ch.setUid(rs.getString("uid"));
			ch.setGisgmp(rs.getString("gisgmp"));
			ch.setSobstv(rs.getString("sobstv"));
			ch.setChargeId(rs.getString("chargeId"));

			listCharges.add(ch);
		}

		//System.out.println(listCharges.size() + " начислений");

		return listCharges;
	}

}
