package utils;

import ru.yandex.qatools.properties.PropertyLoader;
import ru.yandex.qatools.properties.annotations.Property;
import ru.yandex.qatools.properties.annotations.Resource;

/**
 * Класс получения настроек для тестов из test.properties
 */
@Resource.Classpath("gisgmp.properties")
// @Resource.File("C://temp//gisgmp.properties")
public class Config {
	private static Config config;

	private Config() {
		PropertyLoader.populate(this);

	}

	public static Config getInstance() {
		if (config == null) {
			config = new Config();
		}
		return config;
	}

	@Property("app.server")
	private static String appServer;
	@Property("test.browser")
	private static String browserShortName;
	@Property("user.login")
	private static String userLogin;
	@Property("user.password")
	private static String userPassword;
	@Property("bd.host")
	private static String bd_host;
	@Property("bd.name")
	private static String bd_name;
	@Property("bd.user")
	private static String bd_user;
	@Property("bd.pass")
	private static String bd_pass;
	@Property("chromedriverpath")
	private static String chromedriverpath;
	@Property("import.type")
	private static String import_type;
	
	//////////
	// Методы//
	//////////

	public String getImportType() {
		return import_type;
	}
	
	public String getAppServer() {
		return appServer;
	}

	public String getAppLoginPageUrl() {
		String result = "http://" + appServer;
		return result;
	}

	public String getUserLogin() {
		return userLogin;
	}

	public String getUserPassword() {
		return userPassword;
	}

	public String getBdHost() {
		String result = "jdbc:postgresql://" + bd_host + "/";
		return result;
	}

	public String getBdName() {
		return bd_name;
	}

	public String getBdUser() {
		return bd_user;
	}

	public String getBdPass() {
		return bd_pass;
	}

	public String getChromedriverPath() {
		return chromedriverpath;
	}
}
