package utils;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import units.InnKpp;

public class RegexParce {

	/// <summary>
	/// поиск лицевого счета по строке вхождения
	/// </summary>
	/// <param name="input"></param>
	/// <returns></returns>
	public static InnKpp getInnKpp(String input) {
		input = input.toLowerCase().replace("инн", " инн:").replace("кпп", " кпп:").replace("огрн", " огрн:").replace("бик", " бик:").replace("::", ":").trim();
		// Console.WriteLine(input);
		InnKpp ik = new InnKpp();

		Pattern regex = Pattern.compile("\\b([0-9]{9,10})\\b|\\b([0-9]{12})\\b", Pattern.CASE_INSENSITIVE);//"\\b([0-9]{9,10,12})\\b" - неверный {}

		Matcher m = regex.matcher(input);

		// if (m.matches())
		{
			// отображаем все совпадения
			while (m.find()) {
				//System.out.println(m.group());

				/*
				 * 24.03.2017 УБРАЛ ВАЛИДАЦИЮ ИНН if
				 * (InnKpp.check_INN(m.group()))
				 */
				if (m.group().length() == 10 || m.group().length() == 12)
					ik.setInn(m.group());

				
				if (m.group().length() == 9 && InnKpp.check_KPP(m.group()))
					ik.setKpp(m.group());

				// если нет кпп и есть ИНН - придумываем)
				// if (String.IsNullOrEmpty(ik.kpp) &&
				// !string.IsNullOrEmpty(ik.inn))
				if (ik.getKpp() == null && ik.getInn() != null) {

					// ik.kpp = "645x01001".Replace("x", ik.inn.Substring(3,1));
					ik.setKpp("xxxx01001".replace("xxxx", ik.getInn().substring(0, 4)));
				}
			}
			// System.out.println(ik.getInn() + " " + ik.getKpp());
			return ik;
		} // else return null;
	}

	/**
	 * получить паспорт
	 * 
	 * @param input
	 * @return
	 */
	public static String getPasp(String input) {
		String result = "";
		/*
		 * Pattern regex = Pattern.compile("\\b[0-9]{4,6}\\b",
		 * Pattern.CASE_INSENSITIVE); Matcher m = regex.matcher(input);
		 * 
		 * while (m.find()) { String val = m.group(); result = result + " " +
		 * val; }
		 */
		if (result.length() < 10) {
			String number = input.replaceAll("([0-9]{2}\\.[0-9]{2}\\.[0-9]{4})", "");// удаляем
																						// даты
			number = number.replaceAll("[^0-9]", "");// удаляем все,кроме цифр
			if (number.length() == 10)
				result = number.substring(0, 4) + " " + number.substring(4, 10);
		}

		return result;
	}

}
